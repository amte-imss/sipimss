<?php

class Enum_es {

    const
            __default = 0,
            Envio_solicitud = 1,
            Validado_profesionalizacion = 2,
            Inconformidad_docente = 3,
            Envio_evaluacion = 4,
            Evaluacion = 5,
            Revision = 6,
            Revisado = 7,
            Dictaminado = 8,
            Inactivo = 9
    ;
}

class Enum_eei {
	const
            __default = 0,
            Por_evaluar = 1,
            Revision = 2,
            Completa = 3
    ;
}
