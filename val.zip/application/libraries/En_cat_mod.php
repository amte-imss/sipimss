<?php

class En_cat_mod {

    const
            __default = 0,
            Datos_generales = 1,
            Formacion_del_personal_de_salud = 2,
            Formacion_continua_del_personal_de_salud = 3,
            Ejercicio_profesional_en_salud = 4,
            Desarrollo_de_investigacion_en_salud = 5,
            Formacion_docente = 6,
            Formacion_en_educacion_a_distancia = 7,
            Formacion_en_desarrollo_de_contenidos = 8,
            Formacion_en_diseño_instruccional = 9,
            Formacion_en_investigacion_educativa = 10,
            Otros = 11,
            Becas = 12,
            Actividad_docente = 13,
            Ciclos_clinicos = 14,
            Internado_medico = 15,
            Servicio_social = 16,
            Licenciatura = 17,
            Especialidad_medica = 18,
            Maestria = 19,
            Doctorado = 20,
            Tecnico = 21,
            Postecnico = 22,
            Educacion_continua = 23,
            Directivos_para_la_salud = 24,
            Educacion_Formacion_de_profesores = 25,
            Formacion_de_profesores_en_investigacion = 26,
            Educacion_a_distancia = 27,
            Actividades_de_investigacion_educativa = 28,
            Comites_de_educacion = 29,
            Sinodal_de_examen = 30,
            Coordinador_de_tutores_en_educacion_a_distancia = 31,
            Coordinador_de_curso_en_educacion_a_distancia = 32,
            Direccion_de_tesis = 33,
            Elaboracion_de_material_educativo = 34,
            Comision_laboral = 35,
            Comision_educativa = 36
    ;
}
