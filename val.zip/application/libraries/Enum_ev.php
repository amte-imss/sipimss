<?php

class Enum_ev {

    const
            __default = 0,
            Inicio = 1,
//            Incompleta = 2,
//            Completa = 3,
//            Por_validar_n1 = 4,
//            En_revision_n1 = 5,
//            Correccion_docente = 6,
//            Val_n1_por_validar_n2 = 7,
//            En_revision_n2 = 8,
//            Correccion_n1 = 9,
//            Val_n2_por_validar_profesionalizacion = 10,
//            En_revision_profesionalizacion = 11,
//            Correccion_n2 = 12,
//            Validado = 13,
//            En_revision_de_correccion_n1 = 14,
//            En_revision_de_correccion_n2 = 15
            /**/
            //            Inicio = 1,
            Incompleta = 2,
            Completa = 3,
            Listo_por_validar = 4,
            Por_validar_n1 = 5,
            En_revision_n1 = 6,
            Validado_n1 = 7,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
            Por_validar_n2 = 8,
            En_revision_n2 = 9,
            Validado_n2 = 10,
            Por_validar_profesionalizacion = 11,
            En_revision_profesionalizacion = 12,
            Validado_profesionalizacion = 13

    ;
    /*
      guardar actuación (evaluaciones)
      corregir

     */
}
