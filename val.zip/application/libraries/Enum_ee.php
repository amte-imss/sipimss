<?php

class Enum_ee {

    const
            __default = 0,
            Por_evaluar = 1,
            En_revision = 2,
            Completa = 3,
            Validado_sin_revision = 4

    ;
}
