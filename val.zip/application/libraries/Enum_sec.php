<?php

class Enum_sec {

    const
            __DEFAULT = 0,
            B_ACTIVIDAD_DOCENTE = 'AD',
            B_BECAS_COMISIONES_LABORALES = 'BC',
            B_COMISIONES_ACADEMICAS = 'CA',
            B_DIRECCION_TESIS = 'DT',
            B_FORMACION = 'F',
            B_INVESTIGACION_EDUCATIVA = 'IE',
            B_MATERIAL_EDUCATIVO = 'ME',
            S_COMISIONES_ACADEMICAS = 1,
            S_FOR_PERSONAL_CONTINUA_SALUD = 2,
            S_DESA_INV_SALUD = 3,
            S_ACT_INV_EDU = 4,
            S_BECAS_LABORALES = 5, //BECAS Y COMISIONES LABORALES
            S_FORMACION_PROFESIONAL = 6,
            S_MATERIA_EDUCATIVO = 7,
            S_EDUCACION_DISTANCIA = 8,
            S_ESP_MEDICA = 9,
            S_ACTIVIDAD_DOCENTE = 10,
            S_COMISIONES_LABORALES = 11,
            S_DIRECCION_TESIS = 12

            //*No estan en la  base de datos las siguientes secciones*//
    ;
}