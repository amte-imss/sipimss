$(document).ready(function(){
   $("#dictamenTbl").DataTable({
                        "order": [[ 1, "asc" ]]
                    }); 
});