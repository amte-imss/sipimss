<?php if (isset($mensaje)) { ?>
    <span class="alert-info"><?php echo $mensaje; ?></span>
<?php } ?>