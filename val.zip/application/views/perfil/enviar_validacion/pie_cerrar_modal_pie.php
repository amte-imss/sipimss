<?php ?>
<div class="list-group-item text-center center">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 text-center ">
            <button type="button" id="close_modal_censo" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>