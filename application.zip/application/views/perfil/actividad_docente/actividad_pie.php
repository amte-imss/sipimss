<?php // pr( $identificador);?>
<div class="list-group-item text-right">
    <button id="btn_guardar_actividad_especifica" type="button" class="btn btn-success" onclick="funcion_guargar('<?php echo $identificador;?>')" >
        Guardar 
    </button>
</div>


<!--        <div class="col-md-6">
            <label for='lbl_curso' class="control-label">
                <b class="rojo">*</b>
                 <?php // echo $string_values['lbl_curso']; ?>
            </label>
            <div class="input-group">
                <span class="input-group-addon">
                    <span class="glyphicon glyphicon-education"> </span>
                </span>
                <?php 
//                    echo $this->form_complete->create_element(array('id' => 'ccurso', 'type' => 'dropdown', 
//                        'options' => $ccurso, 
//                        'first' => array('' => $string_values['drop_curso']), 
//                        'value' => '',
//                        'attributes' => array('name' => 'categoria', 'class' => 'form-control', 
//                        'placeholder' => 'Categoría', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 
//                        'title' => $string_values['lbl_curso'] ))); 
                ?>
           </div>
           <?php //   echo form_error_format('ccurso'); ?>
        </div>-->