<?php
class Enum_evec {

    const
            __default = 0,
            Inicio =1,
            No_validado_censo = 2,
            Por_validar_n1 = 3,
            En_revision_n1 = 4,
            Correccion_docente = 5,
            Val_n1_por_validar_n2 = 6,
            En_revision_n2 = 7,
            Correccion_n1 = 8,
            Val_n2_por_validar_profesionalizacion = 9,
            En_revision_profesionalizacion = 10,
            Correccion_n2 = 11,
            Validado_profesionalizacion = 12

    ;
}
